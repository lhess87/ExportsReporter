﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ExportReporterDataAccess.Models
{
    public class SearchCryteria
    {
    }
}
